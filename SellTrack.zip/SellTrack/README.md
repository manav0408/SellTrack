# SellTrack — Documentation complète

> Application de suivi des ventes pour revendeurs Vinted et e-commerce.
> Version 1.0.0

---

## Table des matières

1. [À lire en premier](#à-lire-en-premier)
2. [Démarrage rapide](#démarrage-rapide)
3. [Manuel utilisateur](#manuel-utilisateur)
4. [Manuel administrateur](#manuel-administrateur)
5. [Architecture frontend](#architecture-frontend)
6. [Structure des fichiers](#structure-des-fichiers)
7. [Système d'authentification](#système-dauthentification)
8. [Structure des données](#structure-des-données)
9. [Système de thème (clair / sombre)](#système-de-thème-clair--sombre)
10. [Comment ajouter une nouvelle fonctionnalité](#comment-ajouter-une-nouvelle-fonctionnalité)
11. [Passer en production (Next.js + Prisma + PostgreSQL)](#passer-en-production-nextjs--prisma--postgresql)
12. [Déploiement](#déploiement)
13. [Maintenance et évolutions](#maintenance-et-évolutions)
14. [FAQ et dépannage](#faq-et-dépannage)

---

## À lire en premier

Ce que tu reçois dans ce dossier, c'est une **application web complète, autonome et fonctionnelle**. Tu ouvres `index.html` dans ton navigateur et tu peux **immédiatement** :

- créer un compte
- te connecter
- ajouter / modifier / supprimer des articles vendus
- voir ton dashboard, tes graphiques et tes statistiques
- changer le thème clair / sombre
- exporter / importer tes données
- te connecter en admin pour gérer les utilisateurs

**Toutes les données sont stockées dans le navigateur** (via `localStorage`). Aucun serveur n'est nécessaire pour faire tourner cette version.

### Deux niveaux de produit

Cette doc couvre deux choses :

1. **L'application livrée maintenant** — autonome, frontend uniquement, persistance navigateur. Idéale pour valider le design, tester le produit, ou s'en servir comme outil personnel.
2. **La version "production startup"** — celle décrite dans ton prompt initial : Next.js, Prisma, PostgreSQL, NextAuth, API routes, déploiement Vercel. Le chapitre [Passer en production](#passer-en-production-nextjs--prisma--postgresql) explique étape par étape comment transformer la première en seconde.

---

## Démarrage rapide

### 1. Ouvrir l'application

Double-clique sur **`index.html`**. Ton navigateur s'ouvre sur l'écran de connexion SellTrack.

> Astuce : tu peux aussi héberger ces 3 fichiers (`index.html`, `styles.css`, `app.js` + `logo.png`) sur n'importe quel hébergement statique (Netlify, GitHub Pages, Vercel, OVH…) et y accéder depuis n'importe quel appareil. Voir la section [Déploiement](#déploiement).

### 2. Se connecter en admin

Un compte administrateur est créé automatiquement au premier lancement :

| Champ | Valeur |
|---|---|
| Email | `admin@selltrack.app` |
| Mot de passe | `admin` |

À la connexion, tu verras un onglet **Admin** supplémentaire dans la sidebar.

### 3. Créer un compte utilisateur normal

Clique sur l'onglet **Créer un compte** sur l'écran d'accueil. Renseigne ton nom, ton email et un mot de passe. Le compte est créé instantanément et **8 articles d'exemple** sont ajoutés pour que tu puisses voir tout de suite à quoi ressemble le dashboard avec des données.

---

## Manuel utilisateur

### Le dashboard

C'est la page d'accueil. Elle te donne en un coup d'œil :

- **6 indicateurs clés** : revenu total, bénéfice, articles vendus, total investi, marge moyenne, meilleure vente. Chaque carte affiche aussi l'évolution par rapport à la période précédente (en vert si en hausse, en rouge si en baisse).
- **Le graphique d'évolution** : ventes (courbe verte) vs investissements (courbe rouge) jour par jour.
- **Le résumé latéral** : dernière vente, meilleur mois, tendance générale.
- **Sélecteur de période** en haut à droite : 7 jours, 30 jours, ou tout l'historique.

### Articles vendus

La liste de tous tes articles. Tu peux :

- **Rechercher** par nom ou par marque dans la barre de recherche.
- **Filtrer** par marque ou par état.
- **Basculer** entre vue liste et vue grille (boutons en haut à droite).
- **Modifier** un article (icône crayon) ou **supprimer** (icône poubelle).

### Ajouter un article

Le formulaire est divisé en 3 colonnes :

1. **Image, nom, marque, état, date de vente.**
2. **Prix d'achat, prix de vente, frais de port.** Le **bénéfice est calculé automatiquement** : `prix de vente − prix d'achat − frais de port`.
3. **Prévisualisation en temps réel** : ce qu'on verra dans la liste, avec les chiffres calculés.

L'image se glisse-dépose ou se sélectionne en cliquant sur la zone pointillée. Elle est convertie en base64 et stockée localement (pas d'upload serveur).

> **Astuce productivité** : la date est pré-remplie à aujourd'hui. Si tu vends régulièrement, tu peux saisir 5 articles en moins d'une minute.

### Statistiques

Une vue plus poussée :

- **3 mini-cartes** avec sparklines (mini-courbes) : revenu, investissements, bénéfice.
- **Le grand graphique détaillé**.
- **Analyses** : meilleure période de 7 jours, article le plus rentable, moyenne par vente.

### Paramètres

- **Thème** : clair ou sombre. Le choix est mémorisé.
- **Exporter mes données** : télécharge un fichier JSON contenant tous tes articles. Sauvegarde régulièrement !
- **Importer des données** : injecte un export JSON existant. Les articles importés s'ajoutent à ceux déjà présents.
- **Réinitialiser** : efface tous **tes** articles (les autres utilisateurs ne sont pas touchés).

---

## Manuel administrateur

L'onglet **Admin** n'apparaît dans la sidebar que si tu es connecté avec un compte `role: admin`.

### Tableau de bord admin

5 indicateurs globaux :

- Nombre total d'utilisateurs
- Nombre de comptes suspendus
- Total des articles vendus sur la plateforme
- Chiffre d'affaires global
- Bénéfice global

### Gérer les utilisateurs

Le tableau liste tous les comptes. Sur chaque ligne, à droite, tu as trois actions (sauf sur ton propre compte) :

| Icône | Action |
|---|---|
| 🛡️ bouclier | **Suspendre ou réactiver** le compte. Un utilisateur suspendu ne peut plus se connecter. |
| 👤 utilisateur / 👑 couronne | **Changer le rôle** : promouvoir un utilisateur en admin, ou retirer les droits admin. |
| 🗑️ poubelle | **Supprimer définitivement** le compte et toutes ses ventes. |

> ⚠️ Tu ne peux pas te suspendre toi-même, changer ton propre rôle ou te supprimer. C'est une sécurité pour éviter de te retrouver sans accès admin.

### Créer un nouveau compte admin

Deux méthodes :

1. **Promotion** : crée un compte normal, puis va dans Admin et clique sur l'icône couronne à côté de sa ligne pour le promouvoir.
2. **Édition directe du stockage** (avancé) : voir le chapitre [Structure des données](#structure-des-données).

---

## Architecture frontend

L'application est construite en **JavaScript vanilla**, sans framework. Trois fichiers :

```
SellTrack/
├── index.html      → structure (vues, modales, sidebar)
├── styles.css      → tout le design (light + dark theme)
├── app.js          → toute la logique (auth, routing, CRUD, charts)
└── logo.png        → logo de marque
```

### Pourquoi pas de framework ?

Pour cette première version, vanilla JS rend le projet :

- **Portable** : il s'ouvre dans n'importe quel navigateur, sans installation.
- **Lisible** : un seul fichier JS, tu peux le lire de bout en bout en 20 minutes.
- **Pédagogique** : c'est plus facile pour comprendre comment fonctionne le routing, l'auth, le rendu.

Pour la version production (voir plus bas), on passe naturellement sur Next.js + React.

### Le pattern principal

```
                    ┌──────────────────┐
                    │   index.html     │
                    │   (5 vues +      │
                    │    auth + admin) │
                    └────────┬─────────┘
                             │ hash routing (#dashboard, #sales, …)
                             ▼
                    ┌──────────────────┐
                    │     app.js       │
                    │                  │
                    │  ┌────────────┐  │
                    │  │ Auth       │──┼──► localStorage (selltrack:session:v1)
                    │  ├────────────┤  │
                    │  │ Storage    │──┼──► localStorage (selltrack:store:v1)
                    │  ├────────────┤  │
                    │  │ Router     │  │
                    │  ├────────────┤  │
                    │  │ Renderers  │  │  renderDashboard, renderSales,
                    │  │            │  │  renderStats, renderAdmin, …
                    │  ├────────────┤  │
                    │  │ Charts     │──┼──► Chart.js (CDN)
                    │  └────────────┘  │
                    └──────────────────┘
```

### Le routing

C'est un routing basé sur le **hash** de l'URL (`#dashboard`, `#sales`, etc.). Quand l'utilisateur clique sur un lien de la sidebar, l'URL change, l'événement `hashchange` se déclenche, et la fonction `handleRoute()` met à jour la vue affichée.

Avantage : pas besoin de serveur, ça marche en local ou via simple hébergement statique.

### Le rendu des vues

Chaque vue est une `<section>` dans le HTML, masquée par défaut. La fonction `handleRoute()` :

1. Met à jour les liens actifs dans la sidebar.
2. Cache toutes les sections sauf celle qui correspond à la route.
3. Appelle le `render*()` correspondant pour générer le contenu dynamique.

---

## Structure des fichiers

### `index.html`

Le fichier est divisé en grandes zones, dans l'ordre :

| Zone | Lignes (approx.) | Rôle |
|---|---|---|
| `<head>` | 1-20 | Méta, polices Google, CDNs (Chart.js, Lucide) |
| `#auth-shell` | 23-65 | Écran de login / signup |
| `#app-shell` | 68-345 | L'application elle-même |
| `.sidebar` | 71-110 | Navigation de gauche |
| `.main` | 113-340 | Zone principale avec toutes les vues |
| `#modal-root` | 348-361 | Modale réutilisable |
| `#toast-root` | 363 | Container pour les notifications |

### `styles.css`

Organisé en sections claires :

| Section | Contenu |
|---|---|
| `:root` | Toutes les variables de couleur (light theme) |
| `:root[data-theme="dark"]` | Override des variables pour le dark theme |
| `.auth-shell` | Écran de connexion (gradient, glassmorphism) |
| `.app-shell` | Layout principal (grid sidebar + main) |
| `.sidebar` | Navigation de gauche |
| `.card` | Carte générique |
| `.kpi-*` | Cartes KPI avec leurs variantes pastel |
| `.btn-*` | Tous les boutons |
| `.sale-item` | Lignes du tableau de ventes |
| `.dropzone`, `.preview-card` | Composants du formulaire d'ajout |
| `.modal-*`, `.toast-*` | Overlays |
| `@media` | Responsive |

### `app.js`

Structure interne :

```
1.  UTILITIES        → helpers (format €, hash mot de passe, dataURL, …)
2.  STORAGE LAYER    → load/save dans localStorage
3.  AUTH             → signup, login, logout, session
4.  DATA HELPERS     → calculs (aggrégation, périodes, deltas)
5.  UI : TOAST/MODAL → notifications et confirmations
6.  THEME            → light/dark switching
7.  AUTH UI          → bind sur les formulaires de login/signup
8.  APP CHROME       → sidebar, avatar, mobile menu
9.  ROUTING          → handleRoute + nav active
10. CHARTS           → Chart.js (dashboard, stats, sparklines)
11. VIEW : DASHBOARD → renderDashboard()
12. VIEW : SALES     → renderSales() + filtres + CRUD
13. VIEW : ADD       → formulaire et preview live
14. VIEW : STATS     → renderStats() + analyses
15. VIEW : SETTINGS  → thème + export/import/reset
16. VIEW : ADMIN     → renderAdmin() + gestion utilisateurs
17. BOOTSTRAP        → init au chargement de la page
```

---

## Système d'authentification

### Vue d'ensemble

```
[Saisie email/password] → [hashPwd] → [comparaison avec store.users]
                                            │
                              ┌─────────────┴─────────────┐
                              ▼                           ▼
                    [Match : crée session]      [Mismatch : erreur]
                              │
                              ▼
                  localStorage.setItem('selltrack:session:v1',
                                       JSON.stringify({userId}))
```

### Pourquoi c'est suffisant **localement** mais pas **en production**

Dans cette version locale :

- Le mot de passe est haché avec un **hash léger** (DJBX33A). C'est correct pour empêcher la lecture en clair dans le `localStorage`, mais **ce n'est pas un hash cryptographique sûr**.
- Il n'y a pas de **JWT** ni de cookies, juste un identifiant utilisateur stocké dans `localStorage`.
- Toutes les "API" sont en réalité des appels JS internes.

C'est volontaire : sans backend, n'importe qui ayant accès au navigateur peut de toute façon lire `localStorage`. Les vraies sécurités viennent quand on passe en production avec un serveur.

### Comportements

- **Signup** : crée un nouvel utilisateur avec `role: 'user'` et `status: 'active'`. Lui ajoute 8 articles d'exemple pour la démo.
- **Login** : refuse les comptes au statut `banned`.
- **Logout** : supprime la session, retour à l'écran de login.
- **Session persistante** : un utilisateur connecté reste connecté à la prochaine ouverture du navigateur.

---

## Structure des données

Toutes les données sont stockées sous une seule clé `localStorage` : **`selltrack:store:v1`**.

### Schéma de l'objet

```json
{
  "users": [
    {
      "id": "id_xxx",
      "name": "Administrateur",
      "email": "admin@selltrack.app",
      "passwordHash": "h_xxxx_x",
      "role": "admin",              // "admin" | "user"
      "status": "active",           // "active" | "banned"
      "createdAt": "2026-05-22T..."
    }
  ],
  "sales": [
    {
      "id": "id_xxx",
      "userId": "id_xxx",           // FK vers users
      "name": "Nike Tech Fleece",
      "brand": "Nike",
      "condition": "Très bon état",
      "buyPrice": 65,
      "sellPrice": 120,
      "shipping": 5,
      "soldAt": "2026-05-10",       // ISO date
      "image": "data:image/png;base64,…",  // ou null
      "createdAt": "2026-05-22T..."
    }
  ]
}
```

### Relations

```
       ┌────────────┐         ┌────────────┐
       │   users    │1 ──── n│   sales    │
       │            │         │            │
       │ id (PK)    │←────────│ userId(FK) │
       │ name       │         │ name       │
       │ email      │         │ brand      │
       │ role       │         │ condition  │
       │ status     │         │ buyPrice   │
       │ pwdHash    │         │ sellPrice  │
       └────────────┘         │ shipping   │
                              │ soldAt     │
                              │ image      │
                              └────────────┘
```

Une relation simple : **un utilisateur a plusieurs ventes** (one-to-many).

### Inspecter ou éditer le stockage manuellement

Dans Chrome / Firefox / Safari, ouvre la console (`F12` ou `Cmd+Opt+I`), puis :

```js
// Lire toutes les données
JSON.parse(localStorage.getItem('selltrack:store:v1'));

// Effacer absolument tout (reset usine)
localStorage.removeItem('selltrack:store:v1');
localStorage.removeItem('selltrack:session:v1');
location.reload();
```

### Sauvegardes

L'export JSON dans **Paramètres > Exporter mes données** est ta meilleure garantie. Fais-le régulièrement. En cas de problème (nettoyage de navigateur, changement de machine), tu pourras tout réimporter.

---

## Système de thème (clair / sombre)

Implémentation très simple, basée sur CSS custom properties :

1. Les couleurs sont déclarées dans `:root { --bg, --card, --text, … }`.
2. Le sélecteur `:root[data-theme="dark"]` redéfinit chaque variable pour le thème sombre.
3. Quand l'utilisateur clique sur "Sombre" dans Paramètres, le JS exécute `document.documentElement.dataset.theme = 'dark'`.
4. Le choix est persisté dans `localStorage` (clé `selltrack:theme`).
5. Les graphiques Chart.js sont redessinés avec des couleurs adaptées (la grille, les ticks, les remplissages d'aire).

Pour ajouter un troisième thème (par exemple "auto" suivant les préférences système), il suffit d'ajouter un nouveau sélecteur et un nouveau bouton.

---

## Comment ajouter une nouvelle fonctionnalité

### Exemple : ajouter un champ "plateforme de vente" (Vinted / Leboncoin / Vestiaire)

**1. Étendre le schéma de données**

Dans `app.js`, dans la fonction de création d'un article, ajoute le champ `platform` :

```js
store.sales.push({
  // …champs existants…
  platform: fd.get('platform') || '',
});
```

**2. Ajouter le champ au formulaire**

Dans `index.html`, à l'intérieur de `.add-col` numéro 1 :

```html
<label class="field">
  <span class="field-label">Plateforme</span>
  <select name="platform">
    <option value="">Sélectionner</option>
    <option>Vinted</option>
    <option>Leboncoin</option>
    <option>Vestiaire Collective</option>
    <option>eBay</option>
    <option>Autre</option>
  </select>
</label>
```

**3. Afficher la plateforme dans la liste des ventes**

Dans `renderSales()`, modifie le template pour insérer la plateforme :

```js
<div class="sale-brand">${esc(s.brand || '—')} · ${esc(s.platform || '')}</div>
```

**4. Ajouter un filtre par plateforme**

C'est exactement le même schéma que le filtre par marque déjà en place : duplique la logique de `#sales-brand-filter` pour `#sales-platform-filter`.

### Exemple : ajouter une nouvelle vue

Si tu veux ajouter une page "Inventaire" (articles achetés mais pas encore vendus) :

1. Ajoute l'entrée dans `ROUTES` (dans `app.js`) : `'inventory'`.
2. Ajoute un lien dans la sidebar HTML : `<a href="#inventory" class="nav-item" data-route="inventory">`.
3. Ajoute la `<section class="view" data-view="inventory" hidden>` dans le HTML.
4. Crée la fonction `renderInventory()` dans `app.js`.
5. Appelle-la depuis `handleRoute()`.

---

## Passer en production (Next.js + Prisma + PostgreSQL)

Le prompt initial mentionne un stack Next.js / Prisma / PostgreSQL / NextAuth. Voici la roadmap concrète pour transformer la version actuelle en application production.

### Étape 1 : créer le projet Next.js

```bash
npx create-next-app@latest selltrack --typescript --tailwind --app
cd selltrack
npm install prisma @prisma/client next-auth bcryptjs recharts lucide-react
npm install -D @types/bcryptjs
npx prisma init
```

### Étape 2 : schéma Prisma

Dans `prisma/schema.prisma` :

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

enum Role {
  USER
  ADMIN
}

enum Status {
  ACTIVE
  BANNED
}

model User {
  id           String   @id @default(cuid())
  name         String
  email        String   @unique
  passwordHash String
  role         Role     @default(USER)
  status       Status   @default(ACTIVE)
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
  sales        Sale[]
  sessions     Session[]
}

model Sale {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  name      String
  brand     String?
  condition String?
  buyPrice  Decimal  @db.Decimal(10, 2)
  sellPrice Decimal  @db.Decimal(10, 2)
  shipping  Decimal  @db.Decimal(10, 2) @default(0)
  soldAt    DateTime @db.Date
  imageUrl  String?  // URL vers du blob storage (S3, Vercel Blob, etc.)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([userId, soldAt])
}

model Session {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  token     String   @unique
  expiresAt DateTime
  createdAt DateTime @default(now())
}
```

Puis :

```bash
npx prisma migrate dev --name init
```

### Étape 3 : API routes

Sous `app/api/`, créer :

| Route | Méthode | Rôle |
|---|---|---|
| `/api/auth/signup` | POST | Crée un user (bcrypt hash) |
| `/api/auth/login` | POST | Vérifie credentials, génère JWT |
| `/api/auth/logout` | POST | Invalide la session |
| `/api/sales` | GET, POST | Liste / crée une vente (user courant uniquement) |
| `/api/sales/[id]` | GET, PUT, DELETE | CRUD d'une vente |
| `/api/admin/users` | GET | Liste tous les users (admin only) |
| `/api/admin/users/[id]` | PATCH, DELETE | Update role/status, ou supprime (admin only) |
| `/api/stats` | GET | Agrégations dashboard / stats |

Sécurité à chaque appel : `middleware.ts` qui vérifie le JWT, et chaque route admin vérifie que `user.role === 'ADMIN'`.

### Étape 4 : authentification avec NextAuth

NextAuth gère bien les credentials providers. Configuration minimale :

```ts
// app/api/auth/[...nextauth]/route.ts
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

const handler = NextAuth({
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: { email: {}, password: {} },
      async authorize(creds) {
        const user = await prisma.user.findUnique({ where: { email: creds.email } });
        if (!user || user.status === "BANNED") return null;
        const ok = await bcrypt.compare(creds.password, user.passwordHash);
        return ok ? { id: user.id, name: user.name, email: user.email, role: user.role } : null;
      },
    }),
  ],
  session: { strategy: "jwt" },
  callbacks: {
    async jwt({ token, user }) { if (user) token.role = (user as any).role; return token; },
    async session({ session, token }) { (session.user as any).role = token.role; return session; },
  },
});
export { handler as GET, handler as POST };
```

### Étape 5 : composants React

Tu peux reprendre **tout le HTML/CSS** déjà écrit. Il suffit de :

1. Découper les vues en composants React (`<Dashboard />`, `<SalesList />`, etc.).
2. Remplacer les appels `userSales()` par `fetch('/api/sales')` (ou mieux, par un client comme TanStack Query / SWR).
3. Garder les classes Tailwind ou réutiliser le CSS actuel tel quel.

Le design est déjà validé et fonctionnel. Tu ne fais que connecter les données à un vrai backend.

### Étape 6 : upload d'images

Le pattern `dataURL` (base64) utilisé localement n'est pas viable en prod : les bases relationnelles n'aiment pas les blobs de 1+ Mo par ligne. Solution :

- **Vercel Blob Storage** (le plus simple si tu déploies sur Vercel).
- **S3** (AWS) ou **Cloudinary** (le plus flexible).
- Tu stockes uniquement l'**URL** dans le champ `imageUrl` de la table `Sale`.

---

## Déploiement

### Version frontend (actuelle)

C'est statique. Trois options :

**Option 1 — GitHub Pages**

1. Crée un repo GitHub avec les 4 fichiers (`index.html`, `styles.css`, `app.js`, `logo.png`).
2. Dans **Settings > Pages**, choisis `main` comme branche source.
3. L'app est en ligne sous `https://<ton-user>.github.io/<nom-repo>/`.

**Option 2 — Netlify drop**

1. Va sur https://app.netlify.com/drop
2. Glisse le dossier `SellTrack` entier dessus.
3. Tu reçois une URL `https://<nom-aléatoire>.netlify.app`. Tu peux la personnaliser dans les réglages.

**Option 3 — Vercel**

```bash
npm i -g vercel
cd SellTrack
vercel
```

### Version production (Next.js)

Une fois que tu as fait la migration vers Next.js (voir [chapitre dédié](#passer-en-production-nextjs--prisma--postgresql)) :

**Sur Vercel**

```bash
vercel
```

Configure une base PostgreSQL :

- **Vercel Postgres** (intégré, le plus simple).
- **Neon** (gratuit, très généreux).
- **Supabase** (gratuit, avec en plus auth/storage si tu veux remplacer NextAuth).
- **Railway** ou **Render** (alternatives complètes).

Ajoute les variables d'environnement dans **Vercel > Project > Settings > Environment Variables** :

```
DATABASE_URL=postgresql://...
NEXTAUTH_SECRET=<une chaîne random longue>
NEXTAUTH_URL=https://ton-domaine.vercel.app
```

Pour générer le secret : `openssl rand -base64 32`.

---

## Maintenance et évolutions

### Routine recommandée

| Fréquence | Action |
|---|---|
| Hebdomadaire (version locale) | Exporter les données depuis **Paramètres > Exporter** |
| Mensuel | Vérifier les CDN (Chart.js, Lucide) — les versions sont pinnées, donc rien ne casse |
| À chaque évolution | Tester sur Chrome, Firefox, Safari mobile |

### Mettre à jour le design

Tout passe par les **variables CSS** dans `:root`. Si tu veux par exemple changer la couleur principale de violet à bleu :

```css
:root {
  --primary: #2563eb;        /* au lieu de #6e56cf */
  --primary-2: #3b82f6;
  --primary-soft: #dbeafe;
  --primary-soft-2: #eff6ff;
}
```

Tout le produit change de teinte instantanément.

### Mettre à jour le logo

Remplace simplement `logo.png` par ton nouveau fichier (en gardant le même nom). Si tu veux un nom différent, modifie les 3 références dans `index.html` (`<link rel="icon">`, l'image dans auth, et l'image dans sidebar).

### Migrer les données vers une nouvelle version

Tant que tu gardes la clé `selltrack:store:v1`, tes données sont conservées. Si tu introduis un breaking change (nouveau champ obligatoire, suppression d'un champ), incrémente la version : `selltrack:store:v2` et écris une fonction de migration au boot.

---

## FAQ et dépannage

**"J'ai perdu mes données après avoir vidé mon navigateur."**

Le `localStorage` est nettoyé quand tu vides les données de site. La sauvegarde est ta responsabilité : utilise **Paramètres > Exporter mes données** régulièrement.

---

**"Je ne vois pas l'onglet Admin."**

Tu n'es probablement pas connecté avec un compte admin. Déconnecte-toi, reconnecte-toi avec `admin@selltrack.app` / `admin`. Si tu as supprimé ce compte sans en créer un autre, ouvre la console (`F12`) et tape :

```js
localStorage.removeItem('selltrack:store:v1');
localStorage.removeItem('selltrack:session:v1');
location.reload();
```

Cela réinitialise tout et recrée l'admin par défaut.

---

**"Comment changer le mot de passe de l'admin par défaut ?"**

Connecte-toi en admin, ouvre la console et tape :

```js
const store = JSON.parse(localStorage.getItem('selltrack:store:v1'));
// Le hashPwd interne est : 'h_<hexhash>_<longueur>'
// Pour faire simple : crée un nouveau compte normal, puis promeus-le admin
// depuis le panneau, puis supprime l'ancien admin.
```

C'est volontairement contraignant côté local ; en version production, ce sera juste un endpoint API `/api/admin/users/:id` avec un PATCH.

---

**"Le graphique ne s'affiche pas / il est vide."**

Vérifie que tu as bien des ventes dans la période sélectionnée (essaie "Tout" dans le menu de période). Sinon, vérifie dans la console (`F12`) qu'il n'y a pas d'erreur réseau qui bloquerait Chart.js depuis le CDN.

---

**"Comment ajouter d'autres devises (USD, GBP, etc.) ?"**

Dans `app.js`, la fonction `fmtEUR` peut être paramétrée par devise. Tu peux ajouter un champ dans `users` (`currency: 'EUR'` ou `'USD'`), et formater selon le user courant.

---

**"L'application est-elle utilisable sur mobile ?"**

Oui, le layout est responsive. Sur petit écran, la sidebar devient un menu hamburger. Sur tablette, le tableau de ventes passe en grille à 2 colonnes.

---

## Crédits techniques

- **Chart.js** v4.4.1 — graphiques
- **Lucide** v0.469.0 — icônes
- **Plus Jakarta Sans** et **Manrope** — typographies
- Design inspiré des produits SaaS modernes : Linear, Notion, Stripe Dashboard, Canva

---

*Bon développement avec SellTrack 🚀*
